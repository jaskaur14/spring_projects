package com.codingdojo.dojos.logAndReg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogAndRegApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogAndRegApplication.class, args);
	}

}
