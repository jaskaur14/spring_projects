package com.codingdojo.omikuji;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmikujiApplicationTests {

	@Test
	void contextLoads() {
	}

}
